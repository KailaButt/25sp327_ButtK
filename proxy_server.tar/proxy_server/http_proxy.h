#ifndef HTTP_PROXY_H
#define HTTP_PROXY_H

extern void handle_client_request_thread(void *arg);

#endif